-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1466640)
addappid(1466641,0,"4002fa24b467f86f7d65fb8a377d33358f83d3b42ebe25cc72332820bafcea85")
--setManifestid(1466641,"1278914480800819686")
addappid(1681090,0,"e849c920b7bd10b6cd085dd924dcc425c8526ca5adef4f3bcc6d5d76edbc523c")
--setManifestid(1681090,"5843759502219600104")
addappid(1782160,0,"76552fd3f798c97e0f65596b191fff61ae78efa157fff76de8fbb409d322755e")
--setManifestid(1782160,"4289489805529103210")