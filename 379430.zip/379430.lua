-- 379430's Lua and Manifest Created by Hubcap Manifest
-- Kingdom Come: Deliverance
-- Created: April 14, 2026 at 15:13:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 14
-- Total DLCs: 11
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(379430, 1, "fdb320571e09066114da93da67a1874b282dc8db0d61419a72b89381894b3363") -- Kingdom Come: Deliverance
-- MAIN APP DEPOTS
addappid(379432, 1, "108f95cce2562576671a8d1deb159b583397b664cafabd96f622beaae2a38655") -- goldmaster
setManifestid(379432, "5694983311934705492", 64160333425)
addappid(379433, 1, "b73a679f54e714c4f1faf2c054cb3acaf90fcdd998e96984742b9f5f20d5325e") -- goldmaster_bin
setManifestid(379433, "717100730472011277", 49239046)
addappid(379436, 1, "5a4593b96f530a9d8280e22d4ec8b80af706a8bfe9a073b0e6fafc1f5e10e2c0") -- review_package
setManifestid(379436, "6811928840428249954", 30)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Kingdom Come Deliverance - Artbook (AppID: 801980)
addappid(801980)
addappid(379431, 1, "28025aa521351af4da4b05336ce0cdeb467cf54ab15af771b6e96e777e6e11ef") -- Kingdom Come Deliverance - Artbook - Kingdom Come: Deliverance: Artbook
setManifestid(379431, "3231236415084706454", 131369286)
-- Kingdom Come Deliverance - HD Texture Pack (AppID: 836890)
addappid(836890)
addappid(836890, 1, "7e4b67dfff0691c120ae20411dd923d92fe00e434fc66529e528c431dcacf0ef") -- Kingdom Come Deliverance - HD Texture Pack - Kingdom Come: Deliverance - HD Texture Pack (836890) Depot
setManifestid(836890, "1375049741468394017", 7062303261)
-- Kingdom Come Deliverance - HD Sound Pack (AppID: 836900)
addappid(836900)
addappid(836900, 1, "d131517918735f795946cf9898da1e5f69df47f9e2f4a6f572f74ab375f3152d") -- Kingdom Come Deliverance - HD Sound Pack - Kingdom Come: Deliverance - HD Sound Pack (836900) Depot
setManifestid(836900, "6319390312926829540", 431165971)
-- Kingdom Come Deliverance - HD Voice Pack - English (AppID: 836910)
addappid(836910)
addappid(836910, 1, "fde946d787d448a9ad59c6b49c4c8ed56da692d161669d585a82129d4c74be1e") -- Kingdom Come Deliverance - HD Voice Pack - English - Kingdom Come: Deliverance - HD Voice Pack - English (836910) Depot
setManifestid(836910, "1961281874941694896", 4155965915)
-- Kingdom Come Deliverance - HD Voice Pack - German (AppID: 836920)
addappid(836920)
addappid(836920, 1, "abb26620bd532d9519f5c3359a4995bd7def223ec7ddef791fe0b487ecf6eff3") -- Kingdom Come Deliverance - HD Voice Pack - German - Kingdom Come: Deliverance - HD Voice Pack - German (836920) Depot
setManifestid(836920, "2096891146739122223", 4241805372)
-- Kingdom Come Deliverance - HD Voice Pack - French (AppID: 836930)
addappid(836930)
addappid(836930, 1, "479474ba710c10d7b528343e0471cb4e979ad174ef2fefe437dbc0c0f1da8b43") -- Kingdom Come Deliverance - HD Voice Pack - French - Kingdom Come: Deliverance - HD Voice Pack - French (836930) Depot
setManifestid(836930, "4537521641197841292", 4151457257)
-- Kingdom Come Deliverance  The Amorous Adventures of Bold Sir Hans Capon (AppID: 921950)
addappid(921950)
addappid(921950, 1, "7a9065cf0a6bab53fc81761cd1c3ccdd67e1516403d4a59d0a272de7b0c876ff") -- Kingdom Come Deliverance  The Amorous Adventures of Bold Sir Hans Capon - Kingdom Come: Deliverance – The Amorous Adventures of Bold Sir Hans Capon (921950) Depot
setManifestid(921950, "1621685670664125200", 494530076)
-- Kingdom Come Deliverance  Band of Bastards (AppID: 977420)
addappid(977420)
addappid(977420, 1, "aafa5c0edc670ba1c9b40669ccbff37939d12a3484df559cda3a4fa671fdf72f") -- Kingdom Come Deliverance  Band of Bastards - Kingdom Come: Deliverance – Band of Bastards (977420) Depot
setManifestid(977420, "2391667617405966423", 374082246)
-- Kingdom Come Deliverance - A Womans Lot (AppID: 1033890)
addappid(1033890)
addappid(1033890, 1, "4e8ad98af79c5565ecb6850e4f7a582e875c939630f61980a886f6a2e9168c81") -- Kingdom Come Deliverance - A Womans Lot - Kingdom Come: Deliverance - A Woman's Lot (1033890) Depot
setManifestid(1033890, "4286493706647649295", 6991540737)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(768530) -- Kingdom Come Deliverance - Treasures of the Past
addappid(883150) -- Kingdom Come Deliverance  From the Ashes