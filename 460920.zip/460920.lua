-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION 
addappid(460920)
addappid(556390)
addappid(556391)
addappid(556392)
addappid(562850)
addappid(564360)
addappid(564410)
addappid(564411)
addappid(564412)
addappid(564413)
addappid(564414)
addappid(564415)
addappid(564416)
addappid(623290)
addappid(623291)
addappid(686890)
addappid(729770)
addappid(729771)
addappid(730470)
addappid(732380)
addappid(732381)
addappid(744850)
addappid(744851)
addappid(951660)
addappid(951661)
addappid(951662)
addappid(951663)
addappid(951664)
addappid(951665)
addappid(951666)
addappid(951667)
addappid(951668)
addappid(460921,0,"ad7a201700dc69ef545a3ff1a412d171e7b914226451c05bf95162f98f6de430")
setManifestid(460921,"2650336355006182943")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
setManifestid(1716751,"818295193716041715")