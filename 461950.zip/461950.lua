-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(461950)
addappid(228985)
--setManifestid(228985,"3966345552745568756")
addappid(461951,0,"94ec83a8120b2bdb2828e8ce347f44b779ef42ed71c01febef198b9d1dc518f6")
--setManifestid(461951,"2254667426905122248")
addappid(461952,0,"133ffdd781024e74cdec02b5b32b3e76c2c0a363fd685954fffd82d34d39cc80")
--setManifestid(461952,"1583286379000551642")
addappid(461953,0,"e54eb1820052ca8ba4f3e9fb332c9d11c4ac4a13e4f0a85a3cdcd4cfac8975bc")
--setManifestid(461953,"6853173446957310592")