-- 1030300's Lua and Manifest Created by Hubcap Manifest
-- Hollow Knight: Silksong
-- Created: March 25, 2026 at 03:48:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1030300, 1, "a33af0e3d40507ddbcce0f87bd8647020d74f5775c60c5f57833c78d1d0be546") -- Hollow Knight: Silksong
-- MAIN APP DEPOTS
addappid(1030301, 1, "f4a253f96969f93b8a9392cddf6f1b779886ea10a160e7ca148b92bae09abd28") -- Depot 1030301
setManifestid(1030301, "4421626056705534276", 8207380004)
addappid(1030302, 1, "bc736fb6e74601f627b4890559822b4b8e786e36e949b881dcd25419e8a15e9e") -- Depot 1030302
setManifestid(1030302, "4136280015582261500", 8260628780)
addappid(1030303, 1, "ea761f41bd28ae29fd22375e81702eadc64796099fd9dcf01ea2a190536cc7c3") -- Depot 1030303
setManifestid(1030303, "7921642076658611197", 8225770198)