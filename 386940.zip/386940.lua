-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(386940)
addappid(386941,0,"468fd966fb446f6751ea67a25687b0e423fea61638f6b942a41ed6f8eb7f073a")
--setManifestid(386941,"819494070590847490")
addappid(386942,0,"6050a40c785f778d78655ff43408f770ba44ed0f0b066bc88591e84746c3820e")
--setManifestid(386942,"2806442111850230345")