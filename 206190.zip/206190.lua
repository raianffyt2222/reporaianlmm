-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(206190)
addappid(228983)
--setManifestid(228983,"8124929965194586177")
addappid(229020)
--setManifestid(229020,"5799761707845834510")
addappid(206191,0,"c1b5dc2216baa031e4d04165ef205bb0dcf58f82db61a70ac7f73b0f8461ac0f")
--setManifestid(206191,"3942629395423288450")
addappid(206193,0,"dbd2c02ecb79eb95ff434b4ed339567f6da4161c51ad0584f95ea5917be9f0e6")
--setManifestid(206193,"8227386196417807430")
addappid(206194,0,"182a907228d9b79ead476b3ec7b91a5ae4411cb438167719c0f7e04e6a16184a")
--setManifestid(206194,"3504745875957567734")
addappid(206195,0,"b241b0d875dcd79843a371389206ce10c55b576ef1f66912eeee314cd29c82d0")
--setManifestid(206195,"3806011840468391349")
addappid(206198,0,"4099f2ae7aa0c69a898ba17864753a00bf3b76d138f0887c57a9b5333b0e3b75")
--setManifestid(206198,"52362191673854060")