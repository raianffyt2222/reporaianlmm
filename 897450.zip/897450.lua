-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(897450)
addappid(229006)
--setManifestid(229006,"1784011429307107530")
addappid(897451,0,"df0e26a2550f9f01d966469a8644b16bdab4ff313d46eda71b8fdd4c75fbb1bb")
--setManifestid(897451,"7890167199684978257")
addappid(1378760,0,"d0db88f4fc0da49bb2a4bb7db3695cec059a5e8cb791fd5b860665e7af0a9473")
--setManifestid(1378760,"1440457219443394317")