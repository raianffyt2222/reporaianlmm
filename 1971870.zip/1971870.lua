-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION 
addappid(1971870)
addappid(2576730)
addappid(2576740)
addappid(2576750)
addappid(2576760)
addappid(2576770)
addappid(2576780)
addappid(2576790)
addappid(2576800)
addappid(2576810)
addappid(2586300)
addappid(2636080)
addappid(2636090)
addappid(2695680)
addappid(2695690)
addappid(2777460)
addappid(2777480)
addappid(2880670)
addappid(2880680)
addappid(2968440)
addappid(2968450)
addappid(3049390)
addappid(3133990)
addappid(3134000)
addappid(3161240)
addappid(3168140)
addappid(3168150)
addappid(3168160)
addappid(3168170)
addappid(3179910)
addappid(3226640)
addappid(3226650)
addappid(3286290)
addappid(3286300)
addappid(3286310)
addappid(3490300)
addappid(3497710)
addappid(3747420)
addappid(3747600)
addappid(3749220)
addappid(2615191,0,"881b5265b81aaa6e34ba005510561510c74dca7c4ddf56e688110dc4708702f7")
setManifestid(2615191,"4363176120155839027")
addappid(3168021,0,"30cb9e85c44a2e1796c48b863ad72b03f0c8c8944fc32e93af78420d958df89e")
setManifestid(3168021,"9095445288428088123")
addappid(3233541,0,"202206a238ab830b8c5dc5506ae41300989cd12ceadff8bb3c6d554bf3feb56b")
setManifestid(3233541,"9120506324946519517")
addappid(1971874,0,"d7c65f47842d7fe05e6489fd6f86355ebfb7a3f1261c503cdbeebaba66849d82")
setManifestid(1971874,"512005367846038723")
addappid(1971875,0,"020f4d21f49e187c5ee0dc181a3d10cdc166bc935868f83e5add726947973b51")
setManifestid(1971875,"2741683106529194428")
addappid(1971872,0,"2fb68660ef98508853b7901a8c4758d2811c558bc23eb52105126af40209be9c")
setManifestid(1971872,"8552604172369068290")
addappid(1971873,0,"1721fcefd622e29779c2aaf9b3c0b7fbad0d149f94d00e611b8185720bd65afb")
setManifestid(1971873,"5676539294652549514")