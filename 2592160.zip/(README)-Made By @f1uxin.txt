(It is fine to delete/not add this TXT file into steamtools/whatever you got this inside of).

This file was created by f1uxin, enjoy!

And you should really check out my server (https://discord.gg/NmmpgnAgen), we show all of this manifest and lua stuff and just in general everything about piracy.

The redistribution/sharing of these files are NOT allowed without permission, you can share it with a friend but you must not redistribute it and claim it is your own, i use my own money to get the game to make these, or my IRL friend will buy it and let me use it to help others, so people stealing them really upsets me if you do want to redistribute it you can add me on discord "@f1uxin" and we can talk about it.

Socials:

My Discord/Discord Server - User: @f1uxin | My Server : https://discord.gg/NmmpgnAgen


Extra Notes:

On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free

