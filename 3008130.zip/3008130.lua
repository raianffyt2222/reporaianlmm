-- 3008130's Lua and Manifest Created by Hubcap Manifest
-- Dying Light: The Beast
-- Created: April 29, 2026 at 11:36:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 29
-- Total DLCs: 11
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(3008130, 1, "5eacefd012dbfb99c51dc01573afeccbeae511575d049dbdb7a796559d455fa0") -- Dying Light: The Beast
-- MAIN APP DEPOTS
addappid(3008131, 1, "3c9721275b2d1577cdbc46948aaef80104cd4f45a9bc32c20e03345c54652587") -- Depot 3008131
setManifestid(3008131, "7509236200935396898", 7)
addappid(3008132, 1, "6028aa5b91f9bf95194ec527c2ebdccd62e9a5df423e65ce32a73145aaa6c6b3") -- Depot 3008132
setManifestid(3008132, "1936258611528346410", 15206965331)
addappid(3008133, 1, "434623d389db7ee032958e856f56adcc7da748791f86963e54523321e2e57ee9") -- Depot 3008133
setManifestid(3008133, "3674182751778406835", 486248502)
addappid(3008134, 1, "9c4e2acba05efb8e83b8b84191c8ea0454009ee00e7fc407eb32ad2c16cd5d9e") -- Depot 3008134
setManifestid(3008134, "2365756934235829247", 51346790984)
addappid(3008135, 1, "d47e689c1f7c949b76c2d74d998ef7cf4db0ebb66ef327e68a4e7e1b4bc931dd") -- Depot 3008135
setManifestid(3008135, "2409602976524121557", 1857185540)
addappid(3592041, 1, "32f10ad2de76688dc0970aebede422b2921593489edc03e6e1e90d447aeb3890") -- Depot 3592041
setManifestid(3592041, "2605870998215591638", 1494080)
addappid(3592047, 1, "a6d2c01076098ca0ecbe70d4ec21e3c3acfe1671974a526ea883096a51067cec") -- Depot 3592047
setManifestid(3592047, "1343576803886034979", 1494080)
addappid(3008136, 1, "4246c4c3f664e9ac92b6f9bdabea8f9d178d64e7b7f78ce2e47d3261e429d21f") -- Depot 3008136
setManifestid(3008136, "4835321499446250761", 1719567941)
addappid(3008137, 1, "91d23606572ed7cd2a17f0a53854b43ab17be7f90b9121c2e133df6bf9628b15") -- Depot 3008137
setManifestid(3008137, "2203617687536162847", 19047959)
addappid(3008138, 1, "b087b304a3080e8bb9b868f067c8b57d6eac1c0018d81a8d563cc7dcaf6ca050") -- Depot 3008138
setManifestid(3008138, "9124659781447740917", 1726578815)
addappid(3008139, 1, "9ca49a179625bb0a94c6cef85afa175dbf6f70f640eea01565cf29ee9b89b1a4") -- Depot 3008139
setManifestid(3008139, "5890478858748856390", 1695899154)
addappid(3061861, 1, "2f7e9b1d05e7bc30e55829af984f423c7891ecb354db0e336f3cc8f8115aa9a8") -- Depot 3061861
setManifestid(3061861, "80255138283957343", 23565565)
addappid(3061862, 1, "58441f3a3fc23c78ee6ae062b402e98c3881f13b870b2945df538700a9ee98ee") -- Depot 3061862
setManifestid(3061862, "1536755372458729572", 1224375)
addappid(3061863, 1, "5046b1035705c5b2cb125dcffa5f4e5e2fc859a4be1568f05cb1690cd5d8a2ed") -- Depot 3061863
setManifestid(3061863, "7380519459400442377", 1712898399)
addappid(3061864, 1, "38076b913ef2e4d848b83c972e455b0ed335321b7b3275f956819d56618137cc") -- Depot 3061864
setManifestid(3061864, "7457702042064894005", 1172781)
addappid(3061865, 1, "062b2caf7c45bb6c993a1ccc89d4241601e83976f43b4d7a4ec73b6e87a23baf") -- Depot 3061865
setManifestid(3061865, "7349148459753270435", 1700638056)
addappid(3061866, 1, "da6a491e78d34f913d3a35f81992ad8b9554a45ad3405eb90104535c2a190a1c") -- Depot 3061866
setManifestid(3061866, "5570890624782831149", 1687136763)
addappid(3061867, 1, "72b42328ca9c827d6c99a336214d08101a2d1ea131aa4c646a506d94d5c25594") -- Depot 3061867
setManifestid(3061867, "7273726216662452785", 1197977)
addappid(3061868, 1, "4a4e46600e98b44593fe9d6c5f32ffaee4984a804a65841da31aa5f3d562e9c5") -- Depot 3061868
setManifestid(3061868, "1095149725616413652", 1726748223)
addappid(3061869, 1, "a3cc7e3956b21127479c97bde2183a0350a0e00b1866e328210cfd18f9449d2a") -- Depot 3061869
setManifestid(3061869, "324574316684545675", 9103117)
addappid(3592042, 1, "55b8d3f1f8f7b6a5285b4c11635a22a47948493c275ac657e6a3e7ec22a0912b") -- Depot 3592042
setManifestid(3592042, "7772054862312324840", 1182026)
addappid(3592043, 1, "d6564bfa4427ac630cf6a83e8a8dd0da310c59f95cb79634b17a8ce1822922ae") -- Depot 3592043
setManifestid(3592043, "8591703617627218014", 1702870631)
addappid(3592044, 1, "d36aeb87d7dc3805c50fbbbbd0a592b0e112ba31cca48aaba4a4b12169ab4a06") -- Depot 3592044
setManifestid(3592044, "8894426967940888346", 1177097)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Dying Light The Beast - Soundtrack (AppID: 3707620)
addappid(3707620)
addappid(3707623, 1, "e7a49cf3e8049304b31ac9af2380050346b19274b6429680fa656ca2ef8132ff") -- Dying Light The Beast - Soundtrack - Depot 3707623
setManifestid(3707623, "8410235877528022390", 2439074433)
-- Dying Light The Beast - Map Guide (AppID: 3707630)
addappid(3707630)
addappid(3707622, 1, "dbba296c59b4dd12cfbf3e831d228341905cbfe72a6f39b9ab9ab535e2aa2390") -- Dying Light The Beast - Map Guide - Depot 3707622
setManifestid(3707622, "2214401054261555775", 7227782)
-- Dying Light The Beast - Wallpapers (AppID: 3707640)
addappid(3707640)
addappid(3707621, 1, "04cd9ab87835457d4a64c2e33c8bfb34ec9873a58306082dd1554fa31e61b08c") -- Dying Light The Beast - Wallpapers - Depot 3707621
setManifestid(3707621, "6257965437662766979", 64327491)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3592040) -- Dying Light The Beast - Hero Of Harran Bundle
addappid(3707650) -- Dying Light The Beast - Castor Woods Prepper Bundle
addappid(3707710) -- Dying Light The Beast Standard to Deluxe Upgrade
addappid(4355450) -- Dying Light The Beast - Action Hero Essentials
addappid(4355460) -- Dying Light The Beast -  Hunter Essentials
addappid(4355470) -- Dying Light The Beast - Fire Lotus Weapon Pack
addappid(4355480) -- Dying Light The Beast - Discharge Weapon Pack
addappid(4537200) -- Dying Light The Beast Restored Land Definitive Upgrade